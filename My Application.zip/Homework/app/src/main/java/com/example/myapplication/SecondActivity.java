package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;

public class SecondActivity extends  AppCompatActivity{

    Button buttonToClick;
    String answer_login;
    String answer_pass;
    EditText editText;
    EditText editTextTwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);

        buttonToClick = findViewById(R.id.button_to_click);
        editText = findViewById(R.id.edittextlogin);
        editTextTwo = findViewById(R.id.edittextpass);

        buttonToClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                answer_login = editText.getText().toString();
                answer_pass = editTextTwo.getText().toString();
                Intent toMain = new Intent(SecondActivity.this, MainActivity.class);
                String reg_login = answer_login;
                String reg_pass = answer_pass;
                toMain.putExtra("rl", reg_login);
                toMain.putExtra("rp", reg_pass);
                startActivity(toMain);
            }
        });
    } }
