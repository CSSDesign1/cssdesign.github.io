package com.example.myapplication;

import java.util.Scanner;


public class Character {
    public int level;
    public int health;
    public int max_health = 100 + ((level - 1) * 20);
    public int damage; // Пока что не используется, ибо нет боевой системы
    public String name;
    public String[] inventory;

    public Character(String name) {
        level = 1;
        health = 100;
        damage = 5 + ((level - 1) * 5);
        inventory = new String[]{"", "", "", ""};
        this.name = name;
    }

}

