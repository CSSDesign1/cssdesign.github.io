package com.example.myapplication;

import android.util.Log;

public class Situation {

    public Situation[] direction;
    public String[] text;
    public String[] vars;
    public int dHealth;
    public int dDamage; // Эта переменная исчезнет после доработки инвентаря
    public int dLevel;
    public String drop_item;
    public String use_item;
    public int variants;
    public int image;
    public String action = "";


    public Situation(String[] text, String[] var, int variant, int dh, int dd, int dl, String drop, String use, int img, String act) {
        this.text = text;
        vars = var;
        dHealth = dh;
        dDamage = dd;
        dLevel = dl;
        variants = variant;
        direction = new Situation[variants];
        drop_item = drop;
        use_item = use;
        image = img;
        action = act;

    }



}

