package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;



public class MainActivity<typeFace> extends Activity {

    TypeWriter status;
    TypeWriter desc;
    TypeWriter inventory_xml;
    TextView vars;
    LinearLayout line;
    ImageView image;

    static Character hero; // персонаж
    Story story; // история (сюжет)
    int inventory = 0;
    boolean success = true;
    boolean drop = true;

    @SuppressLint("CutPasteId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Typeface tf = Typeface.createFromAsset(getAssets(), "PxPlus_IBM_BIOS.ttf");
        status = findViewById(R.id.status);
        status.setTypeface(tf);
        desc = findViewById(R.id.desc);
        desc.setTypeface(tf);
        inventory_xml = findViewById(R.id.inventory);
        inventory_xml.setTypeface(tf);
        image = findViewById(R.id.image);
        line = findViewById(R.id.layout);
        TextView text = (TextView) findViewById(R.id.desc);
        text.setText("здесь должен быть длинный текст");
        // создаем нового персонажа и историю
        hero = new Character("Джон");
        story = new Story();
        // в первый раз выводим на форму весь необходимый текст и элементы
        // управления
        updateStatus();
    }

    // метод для перехода на нужную ветку развития
    private void go(int i) {
        if (success) {
            story.go(i + 1);
        } else {
            drop = false;
            story.returning();
        }
        updateStatus();
        // если история закончилась, выводим на экран поздравление
        if (story.isEnd())
            Toast.makeText(this, "Игра закончена!", Toast.LENGTH_LONG).show();
    }

    // в этом методе размещаем всю информацию, специфичную для текущей
    // ситуации на форме приложения, а также размещаем кнопки, которые
    // позволят пользователю выбрать дальнейший ход событий
    private void updateStatus() {
        // не забываем обновить репутацию в соответствии с новым
        // состоянием дел

        hero.health += story.current_situation.dHealth;

        hero.damage += story.current_situation.dDamage;



            hero.level += story.current_situation.dLevel;

            if (story.current_situation.drop_item.equals("")) {
            } else {
                if (inventory == 4) {inventory--;}
                hero.inventory[inventory] = story.current_situation.drop_item;
                inventory++;
            }
            if (hero.max_health < hero.health) {
                hero.health = 100;
            }

        // Пример предмета в инвентаре - аптечки
        if (hero.inventory[0].equals("Аптечка") && hero.health < 10) {
            hero.health = hero.health + 50;
            hero.inventory[0] = "";
        } else if (hero.inventory[1].equals("Аптечка") && hero.health < 10) {
            hero.health = hero.health + 50;
            hero.inventory[1] = "";
        } else if (hero.inventory[2].equals("Аптечка") && hero.health < 10) {
            hero.health = hero.health + 50;
            hero.inventory[2] = "";
        }

        // Пример предмета в инвентаре - брони
        if (hero.inventory[0].equals("Костюм хим.защиты") && story.current_situation.dHealth < 0) {
            hero.health = hero.health - (story.current_situation.dHealth / 2);
        } else if (hero.inventory[1].equals("Костюм хим.защиты") && story.current_situation.dHealth < 0) {
            hero.health = hero.health - (story.current_situation.dHealth / 2);
        } else if (hero.inventory[2].equals("Костюм хим.защиты") && story.current_situation.dHealth < 0) {
            hero.health = hero.health - (story.current_situation.dHealth / 2);
        }

        // Пример предмета в инвентаре - лазерного прицела
        if (hero.inventory[0].equals("Лазерный прицел") && story.current_situation.dHealth < 0) {
            hero.damage = hero.damage + 5;
        } else if (hero.inventory[1].equals("Лазерный прицел") && story.current_situation.dHealth < 0) {
            hero.damage = hero.damage + 5;
        } else if (hero.inventory[2].equals("Лазерный прицел") && story.current_situation.dHealth < 0) {
            hero.damage = hero.damage + 5; }

            int b = 0;
            String Inventory = "";
            while (b < 4) {
                if (story.current_situation.use_item.equals(hero.inventory[b])) {
                    success = true;
                    hero.inventory[b] = "";
                    break;
                }
                b++;
                if (b == 4) {
                    success = false;
                    break;
                }
            }
            b = 0;
            while (b < 4) {
                if (b == 4) {b--;}
                Inventory += hero.inventory[b] + " | ";
                b++;
            }
            // выводим статус на форму
            ((TypeWriter) findViewById(R.id.status)).
                    setText("==== Здоровье: " + hero.health +
                            "\n==== Урон оружия: " + hero.damage + "\n==== Уровень: " + hero.level); // + "\n==== Инвентарь: \n" + Inventory
            inventory_xml.setText("-+ Инвентарь +- ");
            final String finalInventory = Inventory;
            inventory_xml.setOnClickListener(new View.OnClickListener() {
                boolean inventory_open = false;

                @Override
                public void onClick(View v) {
                    if (inventory_open == false) {
                        inventory_open = true;
                        inventory_xml.setText("-+ Об игроке +- ");
                    } else {
                        inventory_open = false;
                        inventory_xml.setText("-+ Инвентарь +- ");
                    }
                    if (inventory_open == false) {
                        ((TypeWriter) findViewById(R.id.status)).
                                setText("==== Здоровье: " + hero.health +
                                        "\n==== Урон оружия: " + hero.damage + "\n==== Уровень: " + hero.level);
                    }
                    if (inventory_open == true) {
                        ((TypeWriter) findViewById(R.id.status)).
                                setText(finalInventory);
                    }
                }
            });
            // аналогично для заголовка и описания ситуации
            ((TypeWriter) findViewById(R.id.desc)).
                    animateText(story.current_situation.text[0]);
            desc.setOnClickListener(new View.OnClickListener() {
                int text_i = 0;

                @Override
                public void onClick(View v) {
                    text_i++;
                    if (text_i == story.current_situation.text.length) {
                        text_i = 0;
                    }
                    desc.animateText(story.current_situation.text[text_i]);
                }
            });
            ((LinearLayout) findViewById(R.id.layout)).removeAllViews();
            image.setImageResource(story.current_situation.image);
            // размещаем кнопку для каждого варианта, который пользователь
            // может выбрать
            for (int i = 0; i < story.current_situation.direction.length; i++) {
                Button bu = new Button(this);
                bu.setText(story.current_situation.vars[i]);
                Typeface tf = Typeface.createFromAsset(getAssets(), "PxPlus_IBM_BIOS.ttf");
                bu.setBackgroundColor(Color.BLACK);
                bu.setTextColor(Color.WHITE);
                bu.setTypeface(tf);
                bu.setPadding(0, 0, 0, 0);
                final int buttonId = i;
                // Внимание! в анонимных классах
                // можно использовать только те переменные метода,
                // которые объявлены как final.
                // Создаем объект анонимного класса и устанавливаем его
                // обработчиком нажатия на кнопку
                bu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        go(buttonId);
                        // поскольку анонимный класс имеет полный
                        // доступ к методам и переменным родительского,
                        // то просто вызываем нужный нам метод.
                    }
                });
                // добавляем готовую кнопку на разметку
                ((LinearLayout) findViewById(R.id.layout)).addView(bu);
            }
        }

    }


