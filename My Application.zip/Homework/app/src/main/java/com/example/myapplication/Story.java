package com.example.myapplication;

import android.util.Log;

import java.util.Scanner;

public class Story {

    private Situation start_story;

    private Situation scene_lamp_1;
    private Situation scene_lamp_2;
    private Situation scene_lamp_3;
    private Situation scene_lamp_run;
    private Situation scene_lamp_fight;

    private Situation scene_awakening;
    private Situation scene_awakening_2;
    private Situation scene_street_1;
    private Situation scene_street_2;

    private Situation scene_fight;
    private Situation scene_fight_2;
    private Situation scene_lose;

    private Situation scene_run;
    private Situation scene_bridge;
    private Situation scene_bridge_2;

    private Situation scene_river;
    private Situation scene_river_2;
    private Situation scene_river_death;

    private Situation scene_abandonned;
    private Situation scene_abandonned_2;
    private Situation scene_abandonned_fight;
    private Situation scene_abandonned_sigil;

    private Situation scene_sigil;
    private Situation scene_sigil_answer1;
    private Situation scene_sigil_answer2;
    private Situation scene_sigil_final;


    public Situation current_situation;
    private Situation past;

    // Действия - это массив, хранящий условия, получаемые по ходу игры. Например, при успешном выполнении квеста в Действия заносится информация о его завершении. При получении награды наличие нужного условия проверяется, и в случае успеха награда выдаётся
    // Ранее роль Действий играл инвентарь
    // Условия пока что записываются в Go, в будущем исправлю

    public static String[] actions = new String[]{"", "", "", "", "", "", "", "", "", "", ""};
    public int action_num = 0;
    public int Action_check(String action) { // Собственно, проверка на наличие нужного условия
        int i = 0;
        int res = 2;
        while (i < 10) {
            if (actions[i].equals(action)) {
                res = 1;
                break;
            }
            i++;
        }
        if (res != 1) {
            res = 0;
        }
        return res;
    }

    public static boolean success = true;



    Story() {

        scene_lose = new Situation( // Это не конец. Просто я еще не расписал здесь эту сюжетную ветку
                new String[]{" Вы поднимаете руки вверх ",
                        "Полицейские, не сводя с вас оружия, приказывают пройти в машину \n",
                        "Вам, увы, не хватает сил, чтобы до нее добраться - вы падаете на землю от ранений и головной боли \n",
                        "Свет гаснет. Но это еще не конец... \n"}
                , new String[]{"\n -+ 1 +- Открыть глаза \n"},
                1, -5, 0, 0, "", "", R.drawable.clock, "");

        scene_fight_2 = new Situation(
                new String[]{" Вы не успеваете собраться, как получаете пинок в живот ",
                "После неудачной попытки встать вас самих поднимают и видя, что вы добиты, связывают \n"
                        + "Вы не способны противостоять своим противникам. Вам лишь остаётся ожидать того, что теперь вас ждет \n"
                        + "А что теперь вас ждет? Вы не знаете, что случается с такими, как вы \n" }
                        , new String[]{"\n -+ 1 +- Сдаться \n"},
                1, -25, 0, 0, "", "", R.drawable.shield, "");

        scene_fight_2.direction[0] = scene_lose;

        scene_fight = new Situation(
                new String[]{" Вы быстро находите на земле подходящий камень ",
                "Метким броском вы разбиваете шлем одного из полицейских, но те в ответ открывают огонь из своих орудий \n",
                         "Сплюнув кровью, вы пытаетесь вырваться из хватки стража закона. Это вам удаётся. \n",
                         " Однако не выдержав еще один выстрел, вы падаете и уже не можете драться \n"}
                        , new String[]{"\n -+ 1 +- Сдаться \n", "\n -+ 2 +- Сражаться до последнего \n"},
                2, -50, 0, 0, "", "", R.drawable.shield, "");

        scene_fight.direction[0] = scene_lose;
        scene_fight.direction[1] = scene_fight_2;
        scene_sigil_answer2 = new Situation(
                new String[]{" - Вот и отлично! ",
                        " Наш ждут великие дела, Джон! Не будем медлить! \n",
                        " Я дам тебе карту местности \n",
                        " Передав сверток, Сиджил вдруг куда-то пропадает \n",
                        " Что бы это ни было, это - начало вашего приключения..."}
                , new String[]{"\n -+ 1 +- Начать приключение... \n"},
                1, 0, 0, 1, "", "", R.drawable.sigil, "Договор с Сиджилом");

        scene_sigil_answer2 = new Situation(
                new String[]{" - Ты проберешься на одну из военных баз и ключ-картой получишь доступы к БД ",
                        " А я в это время организую твоё успешное выполнение вышесказанного \n",
                        " Обещаю сравнительную безопасность \n",
                        " Кто не рискует, тот не пьёт шампанское, верно? Ха-ха! \n",
                        " Другого выбора у вас нет. Либо так, либо на расстрел"}
                , new String[]{"\n -+ 1 +- Вернуться к разговору \n", "\n -+ 2 +- Я согласен \n"},
                2, 0, 0, 0, "", "", R.drawable.sigil, "");

        scene_sigil_answer2.direction[1] = scene_sigil_final;


        scene_sigil_answer1 = new Situation(
                new String[]{" - Именно. Я тоже в розыске ",
                        " Этот мир не такой, каким кажется \n",
                        " А я лишь пытался спасти людей... \n",
                        " Как жаль, что ОН ставит гораздо выше другие цели... \n"}
                , new String[]{"\n -+ 1 +- Вернуться к разговору \n", "\n -+ 2 +- Что именно нужно сделать? \n"},
                2, 0, 0, 0, "", "", R.drawable.sigil, "");

        scene_sigil = new Situation(
                new String[]{" - Любопытная встреча - говорит вам незнакомец ",
                        " - Меня зовут д-р Сиджил. А тебя, полагаю, Джон? \n",
                        "Вы недоуменно киваете в ответ \n",
                        "- Так вот - продолжает он - Мне было известно, что ты придёшь \n",
                        "- И у меня есть просьба к тебе. \n",
                        "- У меня есть одно дело с правительством, и ты можешь отлично помочь \n",
                        "- Твоя ключ-карта позволит нам получить доступ к секретной базе данных \n",
                        "- И тогда мы оба исчезнем с радаров и сможем спокойно пожить... \n",
                        " Сиджил ухмыляется \n" }
                , new String[]{"\n -+ 1 +- Оба? С радаров? \n", "\n -+ 2 +- Что именно нужно сделать? \n"},
                2, 0, 0, 0, "", "", R.drawable.sigil, "");

        scene_sigil.direction[0] = scene_sigil_answer1;
        scene_sigil.direction[1] = scene_sigil_answer2;

        scene_sigil_answer1.direction[0] = scene_sigil;
        scene_sigil_answer1.direction[1] = scene_sigil_answer2;
        scene_sigil_answer2.direction[0] = scene_sigil;


        scene_abandonned_sigil = new Situation(
                new String[]{" Вы заходите в куполообразную большую комнату с упавшим потолком ",
                        "Тут тихо, однако странное чувство не покидает вас... \n",
                        "Напрягая слух, вам наконец удается услышать шаги. Увы, слишком поздно \n",
                        "Лазер, выпущенный откуда-то сбоку, обжигает вам плечо \n",
                        "Преодолев боль, вы поднимаете винтовку, но ваш оппонент выбивает ёё из рук \n",
                        "В полуметре от вас стоит мужчина в плаще и странной шляпе \n",
                        "Обдумав что-то, он протягивает руку \n" }
                , new String[]{"\n -+ 1 +- Поздороваться \n"},
                1, -40, 0, 0, "", "", R.drawable.sigil2, "");

        scene_abandonned_sigil.direction[0] = scene_sigil;

        scene_abandonned_fight = new Situation(
                new String[]{" Ваш выстрел попадает в корпус дрона, и тот ударяется об стену ",
                        "Крутясь в воздухе, ваш враг начинает ответный огонь из встроенного пулемета \n",
                        "В прочем, беспорядочно летящие пули удачно пролетают мимо \n",
                        "Вы совершаете контрольный выстрел и быстрым шагом уходите с поля битвы \n" }
                , new String[]{"\n -+ 1 +- Светлое помещение \n"},
                1, 0, 0, 0, "", "", R.drawable.drone, "");

        scene_abandonned_fight.direction[0] = scene_abandonned_sigil;

        scene_abandonned_2 = new Situation(
                new String[]{" На полу вы обнаруживаете винтовку ",
                        "Это оружие очевидно лучше разводного ключа, \n",
                        "и с ним дрон уже не так страшен. А вот и он... \n",
                        "Противно зазвенев, он летит на вас, озаряя коридор зеленоватым светом \n",
                        "Вы с трудом уклоняетесь и заряжаете оружие \n" }
                , new String[]{"\n -+ 1 +- Выстрелить \n"},
                1, 0, +30, 0, "Винтовка", "Разводной ключ", R.drawable.drone, "");

        scene_abandonned_2.direction[0] = scene_abandonned_fight;

        scene_abandonned = new Situation(
                new String[]{" Вы стоите в большом темном помещении ",
                        "Идя на ощупь, вы обнаруживаете свечение в одном из коридоров \n",
                        "Похоже, это охранный дрон... \n",
                        "И зачем он здесь? \n",
                        "Решив не иметь дела с дроном, вы следуете дальше \n" }
                , new String[]{"\n -+ 1 +- Осмотреться \n"},
                1, 0, 0, 0, "", "", R.drawable.drone, "");

        scene_abandonned.direction[0] = scene_abandonned_2;

        scene_river_2 = new Situation(
                new String[]{" Похоже, не в этот раз... ",
                        "Оживленно вдохнув, вы осознаете, что до сих пор живы, и находитесь на суше\n",
                        "Вокруг вы видите не очень-то чистый берег, находящийся перед зданием заброшенного еще очень давно завода \n",
                        "Интересно, почему его до сих пор не восстановили? \n",
                        "Чтобы найти временное укрытие и разгадать эту тайну, вы начинаете двигаться в сторону завода \n" }
                , new String[]{"\n -+ 1 +- Осмотреть дверь \n"},
                1, 0, 0, 0, "", "", R.drawable.clock, "");

        scene_river_2.direction[0] = scene_abandonned;

        scene_river_death = new Situation(
                new String[]{" Игра завершена ",
                "Ваши многообещающие приключения не оправдали ожиданий\n"}
                , new String[]{},
                0, 0, 0, 0, "", "", R.drawable.clock, "");

        scene_river = new Situation(
                new String[]{" Вдохнув побольше воздуха, вы прыгаете в реку ",
                "Прямо за своей спиной вы слышите грохот. Похоже, вы приняли решение вовремя\n",
                        "Однако правильное ли это решение? Как раз подумав об этом, вы сталкиватесь с непонятным обломком \n",
                         "От неожиданности выдохнув, вы начинаете захлебываться. Очень жаль, Джон \n"}
                , new String[]{"\n -+ 1 +- Завершить игру \n"},
                1, -40, 0, 0, "", "", R.drawable.clock, "Шанс");

        // scene_river - строка 267

        scene_bridge_2 = new Situation(
                new String[]{" Не успеваете вы отвлечься, как что-то пугает вас ",
                "Торговый автомат, зазвенев, немного видоизменился и пошел в вашу сторону \n",
                         "Система безопасноти оказалась серьезнее, чем кажется. Вовремя отреагировав, вы прячетесь за обломок \n",
                         "Перед вами - быстрая река, непонятно куда текущая. А от робота вас отделяет только массивный камень \n",
                         "Вдруг вы обнаруживаете старый разводной ключ. Это здорово может помочь \n"}
                        , new String[]{"\n -+ 1 +- Прыгнуть в реку \n", "\n -+ 2 +- Сразиться с торговым автоматом \n"},
                2, 0, +10, 0, "Разводной ключ", "", R.drawable.robot, "");

        scene_bridge_2.direction[0] = scene_river;

        scene_bridge = new Situation(
                new String[]{" Тяжело поднявшись на ноги, вы оглядываетесь по сторонам ",
                "Похоже, вы скатились со склона прямо под мост, а полицейские этого не заметили \n",
                         "Здесь полностью тихо - слышно только шум реки. Рядом стоит сломанный торговый автомат \n" }
                        , new String[]{"\n -+ 1 +- Оценить ситуацию \n"},
                1, 0, 0, 0, "", "", R.drawable.shield, "");

        scene_bridge.direction[0] = scene_bridge_2;

        scene_run = new Situation(
                new String[]{" Недолго думая, вы разворачиваетесь и убегаете ",
                "Предупредив вас о своих намерениях, полицейские открывают по вам огонь. \n",
                         "Одна из пуль пролетает прямо у ваших ушей, когда вы забегаете за угол \n",
                         "Не останавливаясь, вы продолжаете побег, но вдруг подскальзываетесь и катитесь куда-то вниз \n" }
                        , new String[]{"\n -+ 1 +- Встать \n"},
                1, -40, 0, 0, "", "", R.drawable.shield, "");

        scene_run.direction[0] = scene_bridge;

        scene_street_2 = new Situation(
                new String[]{" Наконец вы прогоняете иллюзию, но теперь вам угрожает кое-что другое... ",
                "Придя в себя, вы замечаете, что окружены несколькими стражами закона.",
                         " Похоже, вы выглядите слишком подозрительно \n",
                         " Но если раньше вы бы спокойно прошли с полицейскими, сейчас эта идея кажется очень страшной \n"}
                        , new String[]{"\n -+ 1 +- Бежать \n", "\n -+ 2 +- Сражаться \n"},
                2, 0, 0, 0, "", "", R.drawable.shield, "");

        scene_street_2.direction[0] = scene_run;
        scene_street_2.direction[1] = scene_fight;

        scene_street_1 = new Situation(
                new String[]{" Ваш разум мутнеет, а из толпы выплывает черное нечто ",
                "Вы инстинктивно уклоняетесь, пропуская щупальца твари мимо себя.",
                        "Вам понадобилось некоторое время, чтобы осознать иллюзорную природу существа \n"}
                        , new String[]{"\n -+ 1 +- Преодолеть иллюзию \n"},
                1, 0, 0, 0, "", "", R.drawable.monster_ghost, "");

        scene_street_1.direction[0] = scene_street_2;

        scene_awakening_2 = new Situation(
                new String[]{" На улице прохожие спешат на свои работы, как и вы ",
                "Вы работаете в Реакторе - энергетическом центре города. До него далековато... \n",
                         "Вдруг кто-то окликает вас сзади. Вы не понимаете, кто это был, \n",
                         " и старательно смотрите по сторонам \n"}
                        , new String[]{"\n -+ 1 +- Вглядеться в толпу \n"},
                1, 0, 0, 0, "", "", R.drawable.clock, "");

        scene_awakening_2.direction[0] = scene_street_1;

        scene_awakening = new Situation(
                new String[]{" Вы просыпаетесь в холодном поту ",
                "Интересно - в последний раз вы видели сон пару лет назад. Любопытно, это стоит обсудить на работе с коллегами! \n",
                         "Встав в кровати, вы, еще не отошедшие от увиденного, с трудом одеваетесь и готовы начать свой день! \n" }
                        , new String[]{"\n -+ 1 +- Выйти на улицу \n"},
                1, +100, 0, 0, "Ключ от реактора", "", R.drawable.clock, "");

        scene_awakening.direction[0] = scene_awakening_2;

        scene_lamp_fight = new Situation(
                new String[]{" Собрав волю в кулак, вы ударяете им по горящим глазам неизвестного создания ",
                "Мерзотное бульканье заставляет вас пошатнуться. Жуткая боль прошивает ваше тело, и не в силах удержаться, вы падаете на колени \n",
                         "Вашу голову обвивает странного вида конечность. Хорошо, что в ваши последние секунды темнота не даёт вам увидеть монстра...\n" }
                        , new String[]{"\n -+ 1 +- Позвать на помощь \n"},
                1, -99, 0, 0, "", "", R.drawable.monster_minion, "");

        scene_lamp_fight.direction[0] = scene_awakening;

        scene_lamp_run = new Situation(
                new String[]{" Собрав волю в кулак, вы осмеливаетесь двинуться ",
                "Сзади слышно мерзотное бульканье непонятного происхождения. Но о происхождении вы знать и не хотите\n",
                         "Странная конечность, вроде щупальца, хватает вашу руку и тащит назад. Из него не вырваться...\n"}
                        , new String[]{"\n -+ 1 +- Позвать на помощь \n"},
                1, -109, 0, 0, "", "", R.drawable.monster_minion, "");

        scene_lamp_run.direction[0] = scene_awakening;

        scene_lamp_3 = new Situation(
                new String[]{" В паре сантиметров от вашего лица горит две белоснежные точки ",
                "Это... глаза? Вы, застигнутые врасплох, стараетесь не шевелиться. \n"}
                        , new String[]{"\n -+ 1 +- Бежать \n", "\n -+ 2 +- Атаковать \n"},
                2, 0, 0, 0, "", "", R.drawable.monster_minion, "");

        scene_lamp_3.direction[0] = scene_lamp_run;
        scene_lamp_3.direction[1] = scene_lamp_fight;

        scene_lamp_2 = new Situation(
                new String[]{" Многоголосый шёпот, кажется, жаждет что-то вам сообщить ",
                "Вы не понимаете... Но вот, темнота одерживает верх над светом, и вы медленно отводите руки от глаз \n"}
                        , new String[]{"\n -+ 1 +- Открыть глаза \n"},
                1, 0, 0, 0, "", "", R.drawable.lamp_scene, "");

        scene_lamp_2.direction[0] = scene_lamp_3;

        scene_lamp_1 = new Situation(
                new String[]{" Рано расслабляешься... ",
                " Как только вы выдыхаете, свет от лампы начинает плотнеть... \n",
                         "Ослепительный свет вынуждает вас закрыть глаза рукой. Там, впереди, что-то движется...\n"}
                        ,  new String[]{"\n -+ 1 +- Отступить \n"},
                1, 0, 0, 0, "", "", R.drawable.lamp_scene, "");

        scene_lamp_1.direction[0] = scene_lamp_2;







        start_story = new Situation(
                new String[]{" Вы не понимаете, куда же вас занесло... ",
                "Вокруг лишь темнота, и лампа перед вами. Неестественно резкие тени падают от стенда, на котором она стоит... \n",
                         "Ваше предчувствие не даёт вам притронуться к лампе, а она будто приближается к вам сама...\n",
                         "Пятясь назад, вы старательно пытаетесь отдалиться от неясной угрозы.\n",
                         "Кажется, это прекратилось...\n"}
                , new String[]{"\n -+ 1 +- Выдохнуть \n"},
                1, 0, 0, 0, "Аптечка", "", R.drawable.lamp_scene, "");

        start_story.direction[0] = scene_lamp_1;


        current_situation = start_story;

    }

    public void go(int num) {

        if (num <= current_situation.direction.length) {
            past = current_situation;
            current_situation = current_situation.direction[num - 1];
        } else {
            System.out.println("Вы можете выбирать из "
                    + current_situation.direction.length + " вариантов"); }
        if (!"".equals(current_situation.action)) { Story.actions[action_num] = current_situation.action; action_num++; }
        String TAG = "MyApp";
        Log.v(TAG, "Actions: " + actions[0] + actions[1] + actions[3]);

        // scene_river.direction
        if (Action_check("Шанс") == 1) { scene_river.direction[0] = scene_river_2; }
        else if(Action_check("Шанс") == 0) { scene_river.direction[0] = scene_river_death; }

    }

    public void returning() {
        System.out.println("Увы, действие невозможно");
        current_situation = past;
        current_situation.drop_item = "";
    }

    public boolean isEnd() {
        if (MainActivity.hero.health <= 0) {
            return true;
        }
        return false;
    }
}
